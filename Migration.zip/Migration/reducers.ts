import { ActionTypes, MIGRATION_GET_ALL_REQUEST, MIGRATION_GET_ALL_SUCCESS, MIGRATION_GET_ALL_FAILURE, MigrationIState } from "./types";

const initialState: MigrationIState = {
    loading: false,
    loaded: false,
    error: false,
    success: false,
    errorResp: [],
    migration: []
};
export function MigrationReducer(
    state = initialState,
    action: ActionTypes
): MigrationIState {
    switch (action.type) {
        case MIGRATION_GET_ALL_REQUEST:
            return {
                ...state,
                loading: action.loading,
                loaded: action.loaded,
                error: action.error,
                errorResp: action.errorResp,
                success: action.success,
            }
        case MIGRATION_GET_ALL_SUCCESS:
            return {
                loading: action.loading,
                loaded: action.loaded,
                error: action.error,
                errorResp: action.errorResp,
                success: action.success,
                migration: action.migration
            }
        case MIGRATION_GET_ALL_FAILURE:
            return {
                ...state,
                loading: action.loading,
                loaded: action.loaded,
                error: action.error,
                errorResp: action.errorResp,
                success: action.success,
            }
        default:
            return state;
    }
}