import { MIGRATION_GET_ALL_REQUEST, MIGRATION_GET_ALL_FAILURE, MIGRATION_GET_ALL_SUCCESS } from "./types";
import Middleware from "Store/Middleware";

const middleware = new Middleware();

export function migrationRequest() {
    return {
        type: MIGRATION_GET_ALL_REQUEST,
        loading: true,
        loaded: false,
        error: false,
        success: false
    };
}

export function migrationSuccess(data: any) {
    return {
        type: MIGRATION_GET_ALL_SUCCESS,
        loading: false,
        loaded: true,
        error: false,
        success: true,
        migration: data
    };
}

export function migrationFailure(error: any) {
    return {
        type: MIGRATION_GET_ALL_FAILURE,
        loading: false,
        loaded: true,
        error: true,
        errorResp: error,
        success: false
    };
}

export function serviceMigrationRS(url: string, method: string, reqObj?: any) {

    return (dispatch: any) => {
        dispatch(migrationRequest());
        return middleware.service(url, method, reqObj)
            .then((response: any) => {
               dispatch(migrationSuccess(response));
            }).catch((error: any) => {
               dispatch(migrationFailure(error));
            })
    }
}