export interface MigrationIState {
    loading: boolean,
    loaded: boolean,
    error: boolean,
    errorResp: any,
    success: boolean,
    migration: any;
}

export const MIGRATION_GET_ALL_REQUEST = "MIGRATION_GET_ALL_REQUEST";
export const MIGRATION_GET_ALL_SUCCESS = "MIGRATION_GET_ALL_SUCCESS";
export const MIGRATION_GET_ALL_FAILURE = "MIGRATION_GET_ALL_FAILURE";

type actionType =  typeof MIGRATION_GET_ALL_REQUEST
| typeof MIGRATION_GET_ALL_SUCCESS
| typeof MIGRATION_GET_ALL_FAILURE;

interface Action {
    type: actionType,   
    loading: boolean,
    loaded: boolean,
    error: boolean,
    errorResp: any,
    success: boolean,
    migration: any;
}

export type ActionTypes = Action;